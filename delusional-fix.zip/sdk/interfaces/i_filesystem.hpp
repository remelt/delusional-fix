#pragma once

class i_filesystem {
public:

};