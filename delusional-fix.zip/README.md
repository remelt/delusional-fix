# DELUSIONAL FIX

# SS (for now js imagine fukin delusional menu)
some images for some fucking newgens whov never played w og delusional should be added here

# Fixed :
+ Stability (crashes)
    - prevented crashes when changing teams
    - prevented crashes when turning kz stats on
    - prevented crashes when trying to load if config wasnt selected
    - fixed injection problem because of installed fonts (s/o [@flowars](https://github.com/flowars))
+ Aimbot
    - extended backtrack now can be lower than 200 ms
    - silent aim can be applied separately for every gun type (wasnt actually a bug but ermmm ... who cares)
+ Visuals
    - fixed precipitation (kinda)
+ Movement
    - "unlocked" nn fixed og delusional eb
+ Indicators
    - fixed fading time not saving into cfg and not working properly
+ Skins
    - model changer now applies ur default agent after disabling it
+ Misc
    - fixed hitlog chatprint

# Added :
+ Aimbot
    - added panic key
    - added multiple hitboxes choice
    - added awall checkbox
    - added rcs checkbox and slider
    - awall only if lethal
    - added simple smooth
    - autoshoot
+ Movement
    - added misshop for inui gaming (s/o [@flowars](https://github.com/flowars))
    - added silent option for delusional eb
    - pasted and fixed eb from lobotomy
+ Misc
    - added only local spectatorlist option
    - fixed default music player and added new look
+ Skins
    - added skinchager for weapons
+ Config
    - added load only option (only... aimbot/visuals/movement/indicators/skins/misc)

# TODO :
+ Fix unload
+ Add and fix scaleform, ps and bounce assist from lobotomy

# KNOWN ISSUES :
+ Lb eb is crashing while being used w px (will be fixed 100%)
+ Media player some times doesnt update if the track is on repeat
+ Aimbot sometimes misses (idk y mb u need some kind of bones fix like in hw)
+ Awall only if lethal is kinda ass for some damn reason
+ Rare animations for knives arent working properly
+ Precipitation is ass but idk y (nn i dont have any motivation to fix that shit coz it will take forever)
+ Chatprintf in jumpstats (ig the best option is to recode it :p)

# s/o
[clearlyst for delusional leaked source](https://github.com/clearlyst/delusional/tree/main)
[flowars aka the person who fixed femboyhook v2 for helping me a lot](https://github.com/flowars)
